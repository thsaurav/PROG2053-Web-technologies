const postContainer = document.getElementById('post-container');
let postCount = 0;
function fetchPosts() {
fetch('https://jsonplaceholder.typicode.com/todos/1`)
.then(response => response.json())
.then(data => {
data.forEach(post => {
const postElement = document.createElement('div');
postElement.innerHTML = `
<h3>${post.title}</h3>
<p>${post.body}</p>
`;
postContainer.appendChild(postElement);
});
postCount += 30;
});
}
window.addEventListener('scroll', () => {
if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
fetchPosts();
}
});
fetchPosts();
