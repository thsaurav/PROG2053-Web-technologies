
const cities = [
  { name: 'Oslo', lat: 59.9139, lon: 10.7522 },
  { name: 'Bergen', lat: 60.3929, lon: 5.3242 },
  { name: 'Trondheim', lat: 63.4305, lon: 10.3951 },
  { name: 'Stavanger', lat: 58.9690, lon: 5.7331 },
  { name: 'Tromsø', lat: 69.6492, lon: 18.9553 }
];

let weatherContainer = document.getElementById('weather-container');

cities.forEach(city => {
  fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current_weather=true`)
    .then(response => response.json())
    .then(data => {
      let weatherDiv = document.createElement('div');
      weatherDiv.classList.add('weather');
      weatherDiv.innerHTML = `<h3>${city.name}</h3><p>Temperature: ${data.current_weather.temperature}°C</p>`;
      weatherContainer.appendChild(weatherDiv);
    });
});
    